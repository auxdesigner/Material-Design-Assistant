# Material-Design-Assistant
Chrome extension to copy Material Design HEX value and Shadow CSS
https://chrome.google.com/webstore/detail/material-design-assistant/niibdenamblimiifecjpdamibihicjea


Built with code from:<br />
https://github.com/MikeMitterer/dart-wsk-material  <br>
https://github.com/google/web-starter-kit/tree/material-sprint
